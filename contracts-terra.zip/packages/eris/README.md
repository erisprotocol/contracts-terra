# Eris Staking: Common Types

This crate contains definitions of common types used in Eris Staking.

## License

Contents of this repository are open source under [GNU General Public License v3](https://www.gnu.org/licenses/gpl-3.0.en.html) or later.

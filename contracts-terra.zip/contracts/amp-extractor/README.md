# Eris Yield Extractor

With the Eris Yield Extractor, auto compounding rewards can be extracted from tokens like ampLUNA, STEAK and LUNAX.
It supports harvesting yields to a specified address.

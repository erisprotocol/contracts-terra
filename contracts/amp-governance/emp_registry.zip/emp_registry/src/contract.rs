use std::collections::HashSet;
use std::convert::TryInto;

use astroport::asset::addr_validate_to_lower;
use astroport::common::{claim_ownership, drop_ownership_proposal, propose_new_owner};
#[cfg(not(feature = "library"))]
use cosmwasm_std::entry_point;
use cosmwasm_std::{
    to_binary, Addr, Binary, Deps, DepsMut, Env, MessageInfo, Order, Response, StdError, StdResult,
    Storage, Uint128,
};
use cw2::set_contract_version;
use eris::hub::{get_hub_validators, rebalance_validators_msg};

use eris::emp_registry::{
    AddEmpsStructure, ExecuteMsg, InstantiateMsg, MigrateMsg, QueryMsg, UserInfoResponse,
};
use eris::governance_helper::{calc_voting_power, get_period};

use eris::voting_escrow::{get_lock_info, get_voting_power, LockInfoResponse, LockInfoVPResponse};

use crate::error::ContractError;
use crate::state::{Config, CONFIG, EMP_ID, OWNERSHIP_PROPOSAL};

/// Contract name that is used for migration.
const CONTRACT_NAME: &str = "emp-registry";
/// Contract version that is used for migration.
const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");

type ExecuteResult = Result<Response, ContractError>;

/// Creates a new contract with the specified parameters in the [`InstantiateMsg`].
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn instantiate(
    deps: DepsMut,
    env: Env,
    _info: MessageInfo,
    msg: InstantiateMsg,
) -> ExecuteResult {
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;

    CONFIG.save(
        deps.storage,
        &Config {
            owner: addr_validate_to_lower(deps.api, &msg.owner)?,
            hub_addr: addr_validate_to_lower(deps.api, &msg.hub_addr)?,
        },
    )?;

    EMP_ID.save(deps.storage, &0u128);

    Ok(Response::default())
}

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn execute(deps: DepsMut, env: Env, info: MessageInfo, msg: ExecuteMsg) -> ExecuteResult {
    match msg {
        ExecuteMsg::AddEmp {
            emps,
        } => add_emps(deps, env, info, emps),

        ExecuteMsg::RemoveEmps {
            ids,
        } => remove_emps_by_ids(deps, env, info, ids),
        ExecuteMsg::RemoveAllEmps {
            validator_addr,
        } => remove_emps_by_validator(deps, env, info, validator_addr),

        ExecuteMsg::ProposeNewOwner {
            new_owner,
            expires_in,
        } => {
            let config: Config = CONFIG.load(deps.storage)?;

            propose_new_owner(
                deps,
                info,
                env,
                new_owner,
                expires_in,
                config.owner,
                OWNERSHIP_PROPOSAL,
            )
            .map_err(Into::into)
        },
        ExecuteMsg::DropOwnershipProposal {} => {
            let config: Config = CONFIG.load(deps.storage)?;

            drop_ownership_proposal(deps, info, config.owner, OWNERSHIP_PROPOSAL)
                .map_err(Into::into)
        },
        ExecuteMsg::ClaimOwnership {} => {
            claim_ownership(deps, info, env, OWNERSHIP_PROPOSAL, |deps, new_owner| {
                CONFIG
                    .update::<_, StdError>(deps.storage, |mut v| {
                        v.owner = new_owner;
                        Ok(v)
                    })
                    .map(|_| ())
            })
            .map_err(Into::into)
        },
    }
}

fn add_emps(deps: DepsMut, env: Env, info: MessageInfo, emps: AddEmpsStructure) -> ExecuteResult {
    let user = info.sender;
    let block_period = get_period(env.block.time.seconds())?;
    let config = CONFIG.load(deps.storage)?;

    let allowed_validators = get_hub_validators(&deps.querier, config.hub_addr)?;

    let mut id = EMP_ID.load(deps.storage)?;

    for emp in emps {
        if !allowed_validators.contains(&emp.0) {
            return Err(ContractError::ValidatorNotAllowed {});
        }

        emp.1.into_iter()
    }

    EMP_ID.save(deps.storage, id);

    let user_vp = get_voting_power(&deps.querier, &config.escrow_addr, &user)?;

    if user_vp.is_zero() {
        return Err(ContractError::ZeroVotingPower {});
    }

    let user_info = USER_INFO.may_load(deps.storage, &user)?.unwrap_or_default();

    // Validating addrs and bps
    let votes = emps
        .into_iter()
        .map(|(addr, bps)| {
            if !allowed_validators.contains(&addr) {
                return Err(ContractError::InvalidValidatorAddress(addr));
            }
            let addr = addr_validate_to_lower(deps.api, addr)?;
            let bps: BasicPoints = bps.try_into()?;
            Ok((addr, bps))
        })
        .collect::<Result<Vec<_>, ContractError>>()?;

    // Check the bps sum is within the limit
    votes.iter().try_fold(BasicPoints::default(), |acc, (_, bps)| acc.checked_add(*bps))?;

    remove_votes_of_user(&user_info, block_period, deps.storage)?;

    let ve_lock_info = get_lock_info(&deps.querier, &config.escrow_addr, &user)?;

    apply_votest_of_user(votes, deps, block_period, user_vp, ve_lock_info, env, user)?;

    Ok(Response::new().add_attribute("action", "vote"))
}

fn apply_votest_of_user(
    votes: Vec<(Addr, BasicPoints)>,
    deps: DepsMut,
    block_period: u64,
    user_vp: Uint128,
    ve_lock_info: LockInfoResponse,
    env: Env,
    user: Addr,
) -> Result<(), ContractError> {
    votes.iter().try_for_each(|(pool_addr, bps)| {
        vote_for_pool(
            deps.storage,
            block_period + 1,
            pool_addr,
            *bps,
            user_vp,
            ve_lock_info.slope,
            ve_lock_info.end,
        )
    })?;
    let user_info = UserInfo {
        vote_ts: env.block.time.seconds(),
        voting_power: user_vp,
        slope: ve_lock_info.slope,
        lock_end: ve_lock_info.end,
        votes,
    };
    USER_INFO.save(deps.storage, &user, &user_info)?;
    Ok(())
}

fn remove_votes_of_user(
    user_info: &UserInfo,
    block_period: u64,
    storage: &mut dyn Storage,
) -> Result<(), ContractError> {
    if user_info.lock_end > block_period {
        let user_last_vote_period = get_period(user_info.vote_ts).unwrap_or(block_period);
        // Calculate voting power before changes
        let old_vp_at_period = calc_voting_power(
            user_info.slope,
            user_info.voting_power,
            user_last_vote_period,
            block_period,
        );

        // Cancel changes applied by previous votes
        user_info.votes.iter().try_for_each(|(pool_addr, bps)| {
            cancel_user_changes(
                storage,
                block_period + 1,
                pool_addr,
                *bps,
                old_vp_at_period,
                user_info.slope,
                user_info.lock_end,
            )
        })?;
    };
    Ok(())
}

fn update_vote(
    deps: DepsMut,
    env: Env,
    info: MessageInfo,
    user: String,
    lock: LockInfoVPResponse,
) -> ExecuteResult {
    let block_period = get_period(env.block.time.seconds())?;
    let config = CONFIG.load(deps.storage)?;

    if info.sender != config.escrow_addr {
        return Err(ContractError::Unauthorized {});
    }

    let user = addr_validate_to_lower(deps.api, user)?;
    let user_info = USER_INFO.may_load(deps.storage, &user)?;

    if let Some(user_info) = user_info {
        remove_votes_of_user(&user_info, block_period, deps.storage)?;

        if lock.voting_power.is_zero() {
            return Ok(Response::new().add_attribute("action", "update_vote_removed"));
        }

        apply_votest_of_user(
            user_info.votes,
            deps,
            block_period,
            lock.voting_power,
            lock.lock,
            env,
            user,
        )?;

        return Ok(Response::new().add_attribute("action", "update_vote_changed"));
    }

    Ok(Response::new().add_attribute("action", "update_vote_noop"))
}

/// The function checks that the last pools tuning happened >= 14 days ago.
/// Then it calculates voting power for each pool at the current period, filters all pools which
/// are not eligible to receive allocation points,
/// takes top X pools by voting power, where X is 'config.pools_limit', calculates allocation points
/// for these pools and applies allocation points in generator contract.
fn tune_delegations(deps: DepsMut, env: Env) -> ExecuteResult {
    let mut tune_info = TUNE_INFO.load(deps.storage)?;
    let config = CONFIG.load(deps.storage)?;
    let block_period = get_period(env.block.time.seconds())?;

    if env.block.time.seconds() - tune_info.tune_ts < TUNE_COOLDOWN {
        return Err(ContractError::CooldownError(TUNE_COOLDOWN / DAY));
    }

    let validator_votes: Vec<_> = VALIDATORS
        .keys(deps.as_ref().storage, None, None, Order::Ascending)
        .collect::<Vec<_>>()
        .into_iter()
        .map(|validator_addr| {
            let validator_addr = validator_addr?;

            let validator_info =
                update_validator_info(deps.storage, block_period, &validator_addr, None)?;
            // Remove pools with zero voting power so we won't iterate over them in future
            if validator_info.vamp_amount.is_zero() {
                VALIDATORS.remove(deps.storage, &validator_addr)
            }
            Ok((validator_addr, validator_info.vamp_amount))
        })
        .collect::<StdResult<Vec<_>>>()?
        .into_iter()
        .filter(|(_, vamp_amount)| !vamp_amount.is_zero())
        .sorted_by(|(_, a), (_, b)| b.cmp(a)) // Sort in descending order
        .collect();

    tune_info.validator_points = filter_pools(
        &deps.querier,
        &config.hub_addr,
        validator_votes,
        config.validators_limit, // +1 additional pool if we will need to remove the main pool
    )?;

    if tune_info.validator_points.is_empty() {
        return Err(ContractError::TuneNoValidators {});
    }

    tune_info.tune_ts = env.block.time.seconds();
    TUNE_INFO.save(deps.storage, &tune_info)?;

    // Set new alloc points
    let rebalance_validators_msg = rebalance_validators_msg(config.hub_addr, tune_info)?;

    Ok(Response::new()
        .add_message(rebalance_validators_msg)
        .add_attribute("action", "tune_delegations"))
}

/// Only contract owner can call this function.  
/// The function sets a new limit of blacklisted voters that can be kicked at once.
///
/// * **blacklisted_voters_limit** is a new limit of blacklisted voters which can be kicked at once
///
/// * **main_pool** is a main pool address
///
/// * **main_pool_min_alloc** is a minimum percentage of ASTRO emissions that this pool should get every block
///
/// * **remove_main_pool** should the main pool be removed or not
fn update_config(deps: DepsMut, info: MessageInfo, validators_limit: Option<u64>) -> ExecuteResult {
    let mut config = CONFIG.load(deps.storage)?;

    if info.sender != config.owner {
        return Err(ContractError::Unauthorized {});
    }

    if let Some(validators_limit) = validators_limit {
        config.validators_limit = validators_limit;
    }

    CONFIG.save(deps.storage, &config)?;

    Ok(Response::default().add_attribute("action", "update_config"))
}

/// Expose available contract queries.
///
/// ## Queries
/// * **QueryMsg::UserInfo { user }** Fetch user information
///
/// * **QueryMsg::TuneInfo** Fetch last tuning information
///
/// * **QueryMsg::Config** Fetch contract config
///
/// * **QueryMsg::PoolInfo { pool_addr }** Fetch pool's voting information at the current period.
///
/// * **QueryMsg::PoolInfoAtPeriod { pool_addr, period }** Fetch pool's voting information at a specified period.
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn query(deps: Deps, env: Env, msg: QueryMsg) -> StdResult<Binary> {
    match msg {
        QueryMsg::UserInfo {
            user,
        } => to_binary(&user_info(deps, user)?),
        QueryMsg::TuneInfo {} => to_binary(&TUNE_INFO.load(deps.storage)?),
        QueryMsg::Config {} => to_binary(&CONFIG.load(deps.storage)?),
        QueryMsg::ValidatorInfo {
            validator_addr,
        } => to_binary(&validator_info(deps, env, validator_addr, None)?),
        QueryMsg::ValidatorInfoAtPeriod {
            validator_addr,
            period,
        } => to_binary(&validator_info(deps, env, validator_addr, Some(period))?),
    }
}

/// Returns user information.
fn user_info(deps: Deps, user: String) -> StdResult<UserInfoResponse> {
    let user_addr = addr_validate_to_lower(deps.api, &user)?;
    USER_INFO
        .may_load(deps.storage, &user_addr)?
        .map(UserInfo::into_response)
        .ok_or_else(|| StdError::generic_err("User not found"))
}

/// Returns pool's voting information at a specified period.
fn validator_info(
    deps: Deps,
    env: Env,
    validator_addr: String,
    period: Option<u64>,
) -> StdResult<VotedValidatorInfo> {
    let pool_addr = addr_validate_to_lower(deps.api, &validator_addr)?;
    let block_period = get_period(env.block.time.seconds())?;
    let period = period.unwrap_or(block_period);
    get_validator_info(deps.storage, period, &pool_addr)
}

/// Manages contract migration
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn migrate(_deps: DepsMut, _env: Env, _msg: MigrateMsg) -> Result<Response, ContractError> {
    Err(ContractError::MigrationError {})
}
